# Data_Engineering_with_Databricks

This repository contains relevant notebooks that higlight how to create and manage clusters in databricks, how to use the databricks notebooks and how to orchestrate automated jobs on Databricks. 

The repository also contains Databricks notebooks containing sample Python and SQL ETLs.
